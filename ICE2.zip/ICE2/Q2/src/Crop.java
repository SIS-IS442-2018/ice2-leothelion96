
public class Crop
{
    private String name;
    private char category;

    public Crop(String name, char category)
    {
        this.name = name;
        this.category = category;
    }
    public String getName()
    {
        return name;
    }

    public char getCategory()
    {
        return category;
    }
}
